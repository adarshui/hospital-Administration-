-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2022 at 09:01 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', 'Test@12345', '28-12-2016 11:42:05 AM'),
(2, 'DAYA', 'DAYA@143', '');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `consultancyFees` int(11) DEFAULT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `consultancyFees`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(21, 'bone', 15, 14, 250, '2022-01-18', '11:00 AM', '2022-01-12 17:12:27', 1, 1, NULL),
(22, 'bone', 15, 15, 250, '2022-01-16', '11:15 AM', '2022-01-14 05:36:11', 1, 1, NULL),
(23, 'bone', 15, 11, 250, '2022-01-26', '11:45 PM', '2022-01-16 18:10:42', 1, 1, NULL),
(24, 'bone', 15, 17, 250, '2022-01-26', '12:30 PM', '2022-01-22 06:55:04', 1, 1, NULL),
(25, 'bone', 15, 20, 250, '2022-01-24', '4:00 PM', '2022-01-24 10:24:30', 1, 1, NULL),
(26, 'bone', 16, 20, 500, '2022-01-30', '4:00 PM', '2022-01-24 10:28:53', 1, 1, NULL),
(27, 'bone', 16, 20, 500, '2022-01-21', '4:15 PM', '2022-01-24 10:38:42', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `docFees` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `docFees`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(14, 'Ayurveda', 'Avinash', 'belagavi', '50', 9876543210, 'Avi@gmail.com', '74f59f3eacf87eb5b5f9e67a2d3f4c3e', '2022-01-10 15:40:03', NULL),
(15, 'bone', 'Prajwal Yadav', 'Dandeli', '250', 9663548116, 'p@gmail.com', 'f925f04362c0bc7e4edd6b969dd8cfd0', '2022-01-12 17:00:27', NULL),
(16, 'bone', 'dayanand', 'hjvhv', '500', 8971464515, 'd@gmail.com', '910c0865c45647ddb680f7fd618480a9', '2022-01-24 10:27:04', NULL),
(17, 'bone', 'Pallavi H', 'cgkgtdyotg', '250', 8088510933, 'daya@gmail.com', 'e3480a8108a815dcfacfecda86a31889', '2022-03-30 06:20:14', NULL),
(18, 'bone', 'savitri', 'tdyitgjygo', '300', 9876543210, 's@gmail.com', '72eaa69464b181bec0d176682023423c', '2022-03-30 11:04:29', NULL),
(19, 'bone', 'Pallavi H', 'hjjkh', '250', 8088510933, 'Pal@gamil.com', '46d85374284e4224cbad52d4d7882e08', '2022-03-31 06:12:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(22, 10, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-04 18:30:31', '05-12-2021 12:01:26 AM', 1),
(23, 10, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-04 18:34:00', '05-12-2021 12:05:42 AM', 1),
(24, 10, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-05 07:48:46', '05-12-2021 01:26:43 PM', 1),
(25, 10, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-06 11:20:59', NULL, 1),
(26, NULL, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:44:12', NULL, 0),
(27, NULL, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:44:55', NULL, 0),
(28, NULL, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:45:11', NULL, 0),
(29, 11, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:48:24', NULL, 1),
(30, NULL, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-03 15:10:37', NULL, 0),
(31, 10, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-03 15:10:47', '03-01-2022 09:17:55 PM', 1),
(32, 10, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-03 17:17:10', '03-01-2022 10:58:16 PM', 1),
(33, NULL, 'dayanand', 0x3a3a3100000000000000000000000000, '2022-01-10 15:19:41', NULL, 0),
(34, NULL, 'dayanand', 0x3a3a3100000000000000000000000000, '2022-01-10 15:20:03', NULL, 0),
(35, NULL, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:23:14', NULL, 0),
(36, 13, '1@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:30:11', '10-01-2022 09:03:26 PM', 1),
(37, NULL, 'daya@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:33:37', NULL, 0),
(38, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:42:40', NULL, 1),
(39, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 17:33:23', NULL, 1),
(40, NULL, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-11 08:43:30', NULL, 0),
(41, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-11 08:43:47', '11-01-2022 02:14:08 PM', 1),
(42, NULL, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 10:00:15', NULL, 0),
(43, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 10:00:27', NULL, 1),
(44, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 10:22:11', '12-01-2022 04:10:55 PM', 1),
(45, 15, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 17:01:14', '12-01-2022 10:32:23 PM', 1),
(46, 15, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 17:05:59', '12-01-2022 10:39:27 PM', 1),
(47, 15, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 17:12:49', '12-01-2022 10:47:20 PM', 1),
(48, 15, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 17:20:53', '12-01-2022 10:51:11 PM', 1),
(49, NULL, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-13 08:08:23', NULL, 0),
(50, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-13 08:08:32', '13-01-2022 01:38:53 PM', 1),
(51, NULL, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 04:42:37', NULL, 0),
(52, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 04:42:50', '14-01-2022 10:44:30 AM', 1),
(53, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 05:33:45', '14-01-2022 11:04:12 AM', 1),
(54, 15, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 05:36:43', '14-01-2022 11:07:20 AM', 1),
(55, 14, 'Avi@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-16 18:06:58', '16-01-2022 11:37:41 PM', 1),
(56, 15, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-16 18:11:02', '16-01-2022 11:50:14 PM', 1),
(57, NULL, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:21:34', NULL, 0),
(58, NULL, 'p123@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:22:21', NULL, 0),
(59, 16, 'd@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:27:44', '24-01-2022 03:58:24 PM', 1),
(60, 16, 'd@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:29:14', '24-01-2022 04:00:28 PM', 1),
(61, 16, 'd@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:39:12', '24-01-2022 04:09:31 PM', 1),
(62, 18, 's@gmail.com', 0x3a3a3100000000000000000000000000, '2022-03-30 11:04:57', '30-03-2022 04:35:49 PM', 1),
(63, NULL, 'savitri@gmail,com', 0x3a3a3100000000000000000000000000, '2022-03-31 06:16:34', NULL, 0),
(64, 18, 's@gmail.com', 0x3a3a3100000000000000000000000000, '2022-03-31 06:16:46', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(14, 'bone', '2022-01-11 18:41:58', NULL),
(15, 'bone', '2022-03-30 06:19:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `IsRead` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(4, 'Dayanand Hukkeri', 'dayanandhukkeri515@gmail.com', 897, ' hgtdfhgc', '2021-12-05 07:56:53', 'jgf', '2021-12-05 07:57:37', 1),
(5, 'Dayanand Hukkeri', 'dayanandhukkeri515@gmail.com', 897, ' DSDGDS', '2022-01-10 15:13:26', 'fgd', '2022-01-10 15:32:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

CREATE TABLE `tblmedicalhistory` (
  `ID` int(10) NOT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `BloodSugar` varchar(200) NOT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `MedicalPres` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(10) NOT NULL,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext DEFAULT NULL,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Docid`, `PatientName`, `PatientContno`, `PatientEmail`, `PatientGender`, `PatientAdd`, `PatientAge`, `PatientMedhis`, `CreationDate`, `UpdationDate`) VALUES
(11, 15, 'Dayanand Hukkeri', 8971464515, 'dayanandhukkeri@gmail.com', 'male', 'Sasalatti', 22, 'kjbc', '2022-01-16 18:11:39', NULL),
(12, 16, 'pallavi ', 8088510933, 'pallaviholkar66@gmail.com', 'female', 'jhv', 22, 'mbhm', '2022-01-24 10:30:12', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(24, 8, 'dayanandhukkeri143@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-04 18:15:59', '04-12-2021 11:47:16 PM', 1),
(25, 8, 'dayanandhukkeri143@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-04 18:31:49', '05-12-2021 12:03:38 AM', 1),
(26, NULL, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:40:11', NULL, 0),
(27, 9, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:41:19', '08-12-2021 03:12:25 PM', 1),
(28, 9, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:43:25', '08-12-2021 03:13:54 PM', 1),
(29, NULL, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:47:21', NULL, 0),
(30, NULL, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:47:33', NULL, 0),
(31, 9, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2021-12-08 09:47:41', '08-12-2021 03:18:12 PM', 1),
(32, 10, 'dayanandhukkeri515@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-03 17:29:26', NULL, 1),
(33, 11, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:14:32', '10-01-2022 08:45:14 PM', 1),
(34, 11, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:16:53', '10-01-2022 08:47:47 PM', 1),
(35, 11, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:18:29', NULL, 1),
(36, NULL, 'p@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:40:22', NULL, 0),
(37, 11, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-10 15:40:38', '10-01-2022 09:11:07 PM', 1),
(38, 12, 'dayanandhukkeri575@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-11 08:46:15', '11-01-2022 02:17:36 PM', 1),
(39, 11, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 10:41:29', '12-01-2022 04:29:23 PM', 1),
(40, 13, 'm@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 17:04:44', '12-01-2022 10:35:44 PM', 1),
(41, 14, 's@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-12 17:12:04', '12-01-2022 10:42:35 PM', 1),
(42, NULL, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 05:15:45', NULL, 0),
(43, NULL, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 05:15:55', NULL, 0),
(44, 11, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 05:16:09', '14-01-2022 10:47:35 AM', 1),
(45, 15, 'Varun@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-14 05:35:44', '14-01-2022 11:06:24 AM', 1),
(46, 11, 'dayanandhukkeri@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-16 18:08:01', '16-01-2022 11:40:50 PM', 1),
(47, 17, 'pal@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-22 06:53:25', NULL, 1),
(48, NULL, 'l@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:18:31', NULL, 0),
(49, NULL, 'pal123@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:21:07', NULL, 0),
(50, 20, 'pallaviholkar66@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:23:51', NULL, 1),
(51, 20, 'pallaviholkar66@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:28:40', '24-01-2022 03:59:01 PM', 1),
(52, 20, 'pallaviholkar66@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:30:38', '24-01-2022 04:01:05 PM', 1),
(53, 20, 'pallaviholkar66@gmail.com', 0x3a3a3100000000000000000000000000, '2022-01-24 10:38:11', '24-01-2022 04:08:50 PM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `regDate`, `updationDate`) VALUES
(8, 'Dayanand Hukkeri', 'Sasalatti', 'Sasalatti', 'male', 'dayanandhukkeri143@gmail.com', '7635dd2b9301cbffd254536bba1d7054', '2021-12-04 18:15:44', NULL),
(9, 'pallavi H', 'harugeri', 'Belagavi', 'female', 'p@gmail.com', '25f9e794323b453885f5181f1b624d0b', '2021-12-08 09:40:55', NULL),
(10, 'Dayanand Hukkeri', 'Sasalatti', 'Sasalatti', '', 'dayanandhukkeri515@gmail.com', '7635dd2b9301cbffd254536bba1d7054', '2022-01-03 17:29:02', NULL),
(11, 'Dayanand Hukkeri', 'Sasalatti', 'Sasalatti', 'male', 'dayanandhukkeri@gmail.com', '7635dd2b9301cbffd254536bba1d7054', '2022-01-10 15:14:13', NULL),
(12, 'krishna', 'khanapur', 'khanapur', 'male', 'dayanandhukkeri575@gmail.com', 'd8578edf8458ce06fbc5bb76a58c5ca4', '2022-01-11 08:45:30', '2022-01-11 08:46:41'),
(13, 'Mahesh', 'Bijapur', 'vijyapur', 'male', 'm@gmail.com', '3838573546a6df0f420ef4df425894e5', '2022-01-12 17:04:10', NULL),
(14, 'Supreet B', 'Jugul', 'Belagavi', 'male', 's@gmail.com', '74369d80b537b29d053678448adb1897', '2022-01-12 17:11:40', NULL),
(15, 'Varun Dhavaleshwar', 'gokak', 'gokak', 'male', 'varun@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-01-14 05:35:20', NULL),
(16, 'pallavi H', 'vidya nagar harugeri', 'Harugeri', 'female', 'pal@gmail.com', 'fe8c785fefea634a74503151fed27af8', '2022-01-22 06:50:30', NULL),
(17, 'pallavi H', 'vidya nagar harugeri', 'Harugeri', 'female', 'pal@gmail.com', '2dd020b3c8206a795a604c57317388e4', '2022-01-22 06:51:42', NULL),
(18, 'laxmi', 'kurbet', 'belgavi', 'female', 'l@gmail.com', 'c35cc662178863ac7c8e7e360825d064', '2022-01-24 10:17:40', NULL),
(19, 'pallavi H', 'Sasalatti', 'Sasalatti', 'female', 'pal123@gmail.com', '782e23c9f1dc0821b84bf3f783cc081f', '2022-01-24 10:20:35', NULL),
(20, 'pallavi', 'holkar', 'belgavi', 'female', 'pallaviholkar66@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-01-24 10:23:14', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
