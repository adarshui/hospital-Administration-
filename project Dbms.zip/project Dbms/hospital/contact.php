<?php
include_once('hms/include/config.php');
if (isset($_POST['submit'])) {
	$name = $_POST['fullname'];
	$email = $_POST['emailid'];
	$mobileno = $_POST['mobileno'];
	$dscrption = $_POST['description'];
	$query = mysqli_query($con, "insert into tblcontactus(fullname,email,contactno,message) value('$name','$email','$mobileno','$dscrption')");
	echo "<script>alert('Your information succesfully submitted');</script>";
	echo "<script>window.location.href ='contact.php'</script>";
}


?>
<!DOCTYPE HTML>
<html>

<head>
	<title>HMS | Contact us</title>
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style3.css">
</head>

<body>
	<!--start-wrap-->

	<!--start-header-->
	<nav class="navbar background1 h-nav-resp">
		<ul class="nav-list v-class-resp">
			<div class="logo"><img src="images/22.jpg" alt="logo"></div>
			<li> <a href="index.html">Home </a></li>
			<li> <a href="hms/user-login.php">Patients</a></li>
			<li> <a href="#services">Services </a></li>
			<li> <a href="hms/doctor/">Doctors</a></li>
			<li> <a href="contact.php">Contact </a></li>
			<li> <a href="hms/admin">Admin</a></li>
		</ul>
		<!--<div class="rightNav v-class-resp">
            <input type="text" name="search" id="search">
            <button class="btn btn-sm">Search</button>
        </div>-->
		<div class="burger">
			<div class="line"></div>
			<div class="line"></div>
			<div class="line"></div>
		</div>
	</nav>
	<div class="clear"> </div>
	<div class="wrap" style="background-color: #D1E8E4;background-position: center;background-repeat: no-repeat;background-size: cover;width:inherit;">
		<div class="contact">
			<div class="section group">
				<div class="col span_1_of_3">

					<div class="company_address">
						<h2>Hospital Address :</h2>
						<p>sai circle , Kengerimaddi</p>
						<p>Mahalingapur , Karnatak</p>
						<p>India</p>
						<p>Phone:(+91) 8971464515 </p>
						<p>Fax: (000) 000 00 00 0</p>
						<p>Email: <span>dayanandhukkeri515@gmail.com</span></p>

					</div>
				</div>
				<div class="col span_2_of_3">
					<div class="contact-form">
						<h2>Contact Us</h2>
						<form name="contactus" method="post">
							<div>
								<span><label>NAME</label></span>
								<span><input type="text" name="fullname" required="true" value=""></span>
							</div>
							<div>
								<span><label>E-MAIL</label></span>
								<span><input type="email" name="emailid" required="ture" value=""></span>
							</div>
							<div>
								<span><label>MOBILE.NO</label></span>
								<span><input type="text" name="mobileno" required="true" value=""></span>
							</div>
							<div>
								<span><label>Description</label></span>
								<span><textarea name="description" required="true"> </textarea></span>
							</div>
							<div>
								<span><input type="submit" name="submit" value="Submit"></span>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="clear"> </div>
		</div>
		<div class="clear"> </div>
	</div>
	<footer class="background1">
		<p class="text-footer1">Hospital Address : sai circle , Kengerimaddi Mahalingapur , Karnatak India Phone:(+91) 8971464515 Fax: (000) 000 00 00 0 Email: dayanandhukkeri515@gmail.com

		</p>
	</footer>

	<footer class="background1">
		<p class="text-footer">Copyright &copy; 2022 www.H&H Hospitals.com - All rights reserved

		</p>
	</footer>
	<!--end-wrap-->
</body>

</html>